fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'FiveM RP Team'
description 'Modern Roleplay Loading Screen with interactive music, server rules, and progress bar'
version '1.0.0'

loadscreen 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/app.js'
}
