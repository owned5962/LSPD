Config = {}

Config.Job = 'bus_driver'
Config.Label = 'Chauffeur de Bus Urbain Los Santos Transit'
Config.Category = 'transport'

Config.DutyCoords = vector3(240.0, -1380.0, 33.7)
Config.CloakroomCoords = vector3(242.0, -1382.0, 33.7)
Config.VehicleSpawner = vector3(245.0, -1390.0, 33.7)
Config.VehicleSpawnPoint = vector4(248.0, -1395.0, 33.7, 180.0)

Config.Vehicles = {
    { model = 'burrito3', label = 'Véhicule de service standard' }
}
